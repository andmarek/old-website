Initio - Free, multipurpose html5 template
=============

Initio is a fully featured html5 theme which will help you create a stylish personal or company site. 
6 page layout templates should cover all your development needs. 
Font Awesome 4, parallax effects and more are included (but can be turned off of course)


License
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/


Bug tracker
-----------

Found a bug? Please create an issue here on GitHub! 
https://github.com/pozh/Initio/issues



Credits
-------
* Design and development: **Sergey Pozhilov** - http://pozhilov.com
* More free templates by Sergey: http://gettemplate.com

Photos used in the template
-------
* http://www.publicdomainpictures.net/view-image.php?image=19999
* http://www.publicdomainpictures.net/view-image.php?image=6354
* http://imcreator.com/free/business/macbook-computer
* http://unsplush.com